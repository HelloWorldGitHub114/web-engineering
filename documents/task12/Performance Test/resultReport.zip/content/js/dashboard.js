/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9996904761904762, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "播放获取详情"], "isController": false}, {"data": [1.0, 500, 1500, "获取随机歌手"], "isController": false}, {"data": [1.0, 500, 1500, "获取歌曲"], "isController": false}, {"data": [0.9985, 500, 1500, "findmusic"], "isController": false}, {"data": [1.0, 500, 1500, "用户界面"], "isController": false}, {"data": [1.0, 500, 1500, "歌单风格"], "isController": false}, {"data": [0.9989, 500, 1500, "userdetail"], "isController": false}, {"data": [1.0, 500, 1500, "mv"], "isController": false}, {"data": [1.0, 500, 1500, "查询评论"], "isController": false}, {"data": [1.0, 500, 1500, "login"], "isController": false}, {"data": [1.0, 500, 1500, "歌单内播放"], "isController": false}, {"data": [0.9988, 500, 1500, "newsongs"], "isController": false}, {"data": [1.0, 500, 1500, "歌曲计数"], "isController": false}, {"data": [1.0, 500, 1500, "评论获取"], "isController": false}, {"data": [1.0, 500, 1500, "歌名查询"], "isController": false}, {"data": [0.9994, 500, 1500, "search"], "isController": false}, {"data": [0.9993, 500, 1500, "playlist"], "isController": false}, {"data": [1.0, 500, 1500, "全部歌曲-获取10"], "isController": false}, {"data": [0.9986, 500, 1500, "newmvs"], "isController": false}, {"data": [1.0, 500, 1500, "歌单详情"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 105000, 0, 0.0, 61.282352380952965, 0, 561, 5.0, 42.0, 52.0, 69.9900000000016, 893.9746111210442, 2625.620144999489, 834.8585444816224], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["播放获取详情", 5000, 0, 0.0, 3.574999999999993, 1, 29, 3.0, 6.0, 8.0, 13.0, 42.63410557909906, 116.70253704903774, 39.4698555556503], "isController": false}, {"data": ["获取随机歌手", 5000, 0, 0.0, 30.398999999999866, 3, 171, 27.0, 51.0, 62.0, 89.0, 42.6126678939115, 62.71219776965296, 39.94937615054204], "isController": false}, {"data": ["获取歌曲", 5000, 0, 0.0, 52.715200000000024, 15, 197, 49.0, 75.0, 85.0, 114.0, 42.6188426427092, 557.2080715826081, 39.45572541532062], "isController": false}, {"data": ["findmusic", 5000, 0, 0.0, 177.25639999999981, 0, 561, 179.0, 301.0, 341.0, 430.97999999999956, 88.02506953980493, 56.13317422802014, 80.11656719833809], "isController": false}, {"data": ["用户界面", 5000, 0, 0.0, 3.4446000000000008, 1, 52, 3.0, 6.0, 7.0, 12.0, 42.65156232672803, 35.44578080082574, 39.361060936287096], "isController": false}, {"data": ["歌单风格", 10000, 0, 0.0, 4.9249999999999785, 2, 43, 4.0, 8.0, 10.0, 15.0, 85.26675704942915, 78.5865562835205, 81.31151197145269], "isController": false}, {"data": ["userdetail", 5000, 0, 0.0, 175.96120000000013, 1, 538, 179.0, 299.0, 345.89999999999964, 423.0, 88.16631694027615, 56.223247033203435, 80.2451244026732], "isController": false}, {"data": ["mv", 5000, 0, 0.0, 3.7115999999999905, 1, 29, 3.0, 6.0, 8.0, 13.0, 42.67704572418679, 37.05067739140826, 40.38482158861035], "isController": false}, {"data": ["查询评论", 5000, 0, 0.0, 3.338200000000002, 1, 48, 3.0, 5.0, 7.0, 12.0, 42.64028654272556, 25.400951944397065, 39.89198682415146], "isController": false}, {"data": ["login", 5000, 0, 0.0, 5.687600000000003, 3, 43, 5.0, 9.0, 11.0, 17.0, 42.596331603922266, 46.88092355236367, 43.92746696654484], "isController": false}, {"data": ["歌单内播放", 5000, 0, 0.0, 5.862799999999996, 3, 56, 5.0, 9.0, 12.0, 17.0, 42.63846842621413, 135.4937268153328, 39.7237293736409], "isController": false}, {"data": ["newsongs", 5000, 0, 0.0, 175.10999999999942, 0, 539, 181.0, 299.0, 340.0, 421.97999999999956, 88.09486054583576, 56.17767962542065, 80.18008791867082], "isController": false}, {"data": ["歌曲计数", 5000, 0, 0.0, 33.64379999999989, 5, 167, 30.0, 55.0, 65.0, 95.0, 42.651198498677815, 25.532406913759274, 39.23577049390088], "isController": false}, {"data": ["评论获取", 5000, 0, 0.0, 3.8008000000000064, 2, 36, 3.0, 6.0, 8.0, 13.0, 42.64137748705834, 25.382862936754307, 40.14285927492602], "isController": false}, {"data": ["歌名查询", 5000, 0, 0.0, 16.51980000000002, 9, 80, 15.0, 20.0, 23.0, 30.0, 42.67631720453051, 116.84100497925931, 41.46771056494909], "isController": false}, {"data": ["search", 5000, 0, 0.0, 177.35059999999996, 1, 537, 183.0, 300.90000000000055, 348.0, 423.0, 88.12746756909195, 56.1984729713057, 80.20976540468133], "isController": false}, {"data": ["playlist", 5000, 0, 0.0, 174.83019999999996, 0, 558, 179.0, 294.90000000000055, 340.0, 425.97999999999956, 88.09175637343859, 56.17570010923378, 80.17726263676245], "isController": false}, {"data": ["全部歌曲-获取10", 5000, 0, 0.0, 55.89019999999998, 15, 204, 52.0, 79.0, 91.0, 120.0, 42.63774122302097, 1168.6238722317446, 39.51485978578799], "isController": false}, {"data": ["newmvs", 5000, 0, 0.0, 174.7450000000003, 0, 559, 179.0, 298.0, 341.0, 431.0, 88.11659587966798, 56.19154014592108, 80.19987046860405], "isController": false}, {"data": ["歌单详情", 5000, 0, 0.0, 3.2374, 1, 27, 3.0, 5.0, 7.0, 12.0, 42.63810482151689, 34.60182139324271, 39.515196753534696], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 105000, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
